export function lossPercent(metric) {
    if (!metric || metric.sent === 0)
        return 0;
    return Math.max(0, ((metric.sent - metric.received) / metric.sent) * 100);
}
export function deriveHealth(nodes, metric, degradedRttMs, degradedLossPercent) {
    if (!nodes.length)
        return 'unknown';
    if (nodes.some((node) => !node.online))
        return 'offline';
    if (!metric)
        return 'unknown';
    if (metric.rttP95Ms >= degradedRttMs || lossPercent(metric) >= degradedLossPercent)
        return 'degraded';
    return 'normal';
}
export function percentile95(values) {
    if (!values.length)
        return 0;
    const sorted = [...values].sort((a, b) => a - b);
    return sorted[Math.ceil(sorted.length * 0.95) - 1] ?? 0;
}
